// MODIFIED for VTI_OVERHAUL_LOCK (Project Zomboid mod), 2026.
// Changes: DOOM field made public; added initHeadless(), setInputBits(), getFramePixels() static methods.
// Original source: Mocha Doom - https://github.com/AXDOOMER/mochadoom
// License: GNU General Public License v3 - see LICENSES/mochadoom-GPL-3.0.txt
/*
 * Copyright (C) 2017 Good Sign
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package mochadoom;

import awt.DoomWindow;
import awt.DoomWindowController;
import awt.EventBase.KeyStateInterest;
import static awt.EventBase.KeyStateSatisfaction.*;
import awt.EventHandler;
import doom.CVarManager;
import doom.CommandVariable;
import doom.ConfigManager;
import doom.DoomMain;
import static g.Signals.ScanCode.*;
import g.Signals.ScanCode;
import i.Strings;
import java.io.IOException;
import java.util.Arrays;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Engine {
    private static volatile Engine instance;
    
    /**
     * Mocha Doom engine entry point
     */
    public static void main(final String[] argv) throws IOException {
        final Engine local;
        synchronized (Engine.class) {
            local = new Engine(argv);
        }
        
        /**
         * Add eventHandler listeners to JFrame and its Canvas elememt
         */
        /*content.addKeyListener(listener);        
        content.addMouseListener(listener);
        content.addMouseMotionListener(listener);
        frame.addComponentListener(listener);
        frame.addWindowFocusListener(listener);
        frame.addWindowListener(listener);*/
        // never returns
        try {
            local.DOOM.setupLoop();
        } catch(Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
    }  
    
    public final CVarManager cvm;
    public final ConfigManager cm;
    public DoomWindowController<?, EventHandler> windowController;
    public final DoomMain<?, ?> DOOM;
    
    /** Delegate for normal (windowed) launch. */
    @SuppressWarnings("unchecked")
    private Engine(final String... argv) throws IOException {
        this(argv, false);
    }

    /**
     * Primary constructor.
     * When {@code headless} is true the AWT window creation block is skipped entirely,
     * which avoids GraphicsEnvironment.getDefaultScreenDevice() in environments (like
     * Project Zomboid) where java.awt.headless is permanently true.
     */
    @SuppressWarnings("unchecked")
    private Engine(final String[] argv, final boolean headless) throws IOException {
        instance = this;
        
        // reads command line arguments
        this.cvm = new CVarManager(Arrays.asList(argv));
        
        // reads default.cfg and mochadoom.cfg
        this.cm = new ConfigManager();
        
        // intiializes stuff
        this.DOOM = new DoomMain<>();
        
        if (headless) {
            // Skip all AWT/JFrame/GraphicsDevice calls — not available in headless JVM
            this.windowController = null;
        } else {
            // opens a window
            this.windowController = /*cvm.bool(CommandVariable.AWTFRAME)
                ? */DoomWindow.createCanvasWindowController(
                    DOOM.graphicSystem::getScreenImage,
                    DOOM::PostEvent,
                    DOOM.graphicSystem.getScreenWidth(),
                    DOOM.graphicSystem.getScreenHeight()
                )/* : DoomWindow.createJPanelWindowController(
                    DOOM.graphicSystem::getScreenImage,
                    DOOM::PostEvent,
                    DOOM.graphicSystem.getScreenWidth(),
                    DOOM.graphicSystem.getScreenHeight()
                )*/;
            
            windowController.getObserver().addInterest(
                new KeyStateInterest<>(obs -> {
                    EventHandler.fullscreenChanges(windowController.getObserver(), windowController.switchFullscreen());
                    return WANTS_MORE_ATE;
                }, SC_LALT, SC_ENTER)
            ).addInterest(
                new KeyStateInterest<>(obs -> {
                    if (!windowController.isFullscreen()) {
                        if (DOOM.menuactive || DOOM.paused || DOOM.demoplayback) {
                            EventHandler.menuCaptureChanges(obs, DOOM.mousecaptured = !DOOM.mousecaptured);
                        } else { // can also work when not DOOM.mousecaptured
                            EventHandler.menuCaptureChanges(obs, DOOM.mousecaptured = true);
                        }
                    }
                    return WANTS_MORE_PASS;
                }, SC_LALT)
            ).addInterest(
                new KeyStateInterest<>(obs -> {
                    if (!windowController.isFullscreen() && !DOOM.mousecaptured && DOOM.menuactive) {
                        EventHandler.menuCaptureChanges(obs, DOOM.mousecaptured = true);
                    }
                    
                    return WANTS_MORE_PASS;
                }, SC_ESCAPE)
            ).addInterest(
                new KeyStateInterest<>(obs -> {
                    if (!windowController.isFullscreen() && !DOOM.mousecaptured && DOOM.paused) {
                        EventHandler.menuCaptureChanges(obs, DOOM.mousecaptured = true);
                    }
                    return WANTS_MORE_PASS;
                }, SC_PAUSE)
            );
        }
    }
    
    /**
     * Temporary solution. Will be later moved in more detalied place
     */
    public static void updateFrame() {
        if (instance != null && instance.windowController != null) {
            instance.windowController.updateFrame();
        }
    }
        
    public String getWindowTitle(double frames) {
        if (cvm.bool(CommandVariable.SHOWFPS)) {
            return String.format("%s - %s FPS: %.2f", Strings.MOCHA_DOOM_TITLE, DOOM.bppMode, frames);
        } else {
            return String.format("%s - %s", Strings.MOCHA_DOOM_TITLE, DOOM.bppMode);
        }
    }

    public static Engine getEngine() {
        Engine local = Engine.instance;
        if (local == null) {
            synchronized (Engine.class) {
                local = Engine.instance;
                if (local == null) {
                    try {
                        Engine.instance = local = new Engine();
                    } catch (IOException ex) {
                        Logger.getLogger(Engine.class.getName()).log(Level.SEVERE, null, ex);
                        throw new Error("This launch is DOOMed");
                    }
                }
            }
        }
        
        return local;
    }
    
    public static CVarManager getCVM() {
        return getEngine().cvm;
    }
    
    public static ConfigManager getConfig() {
        return getEngine().cm;
    }

    // -------------------------------------------------------------------------
    // VTI headless integration
    // -------------------------------------------------------------------------

    /**
     * VTI headless integration: create and initialize the Engine without entering
     * the DoomLoop(). Call DOOM.headlessInit() on the returned engine's DOOM field
     * to start episode 1 map 1, then drive with setInputBits() + DOOM.TryRunTics()
     * + DOOM.Display() per frame.
     *
     * @param argv command line args, e.g. {"-iwad", "/path/DOOM1.WAD", "-nosound", "-nomusic"}
     */
    public static Engine initHeadless(String... argv) throws IOException {
        synchronized (Engine.class) {
            if (instance == null) {
                instance = new Engine(argv, true);
            }
        }
        return instance;
    }

    /**
     * KBM patch: drop the cached singleton so the next initHeadless() call
     * builds a fresh Engine (and a fresh DoomMain + WadLoader) for a new
     * IWAD/PWAD pair. Used when the user swaps cartridges in the CRT bridge.
     */
    public static void shutdownHeadless() {
        synchronized (Engine.class) {
            instance = null;
        }
    }

    /**
     * VTI headless integration: inject an input bitmask into gamekeydown[].
     * Uses the default DoomStatus key bindings (WASD + numpad for turn).
     *
     * @param inputBits see VTIDoomEngine.INPUT_* constants
     */
    public static void setInputBits(int inputBits) {
        final boolean[] gkd = getEngine().DOOM.gamekeydown;
        gkd[ScanCode.SC_W.ordinal()]       = (inputBits & 0x001) != 0; // forward
        gkd[ScanCode.SC_S.ordinal()]       = (inputBits & 0x002) != 0; // backward
        gkd[ScanCode.SC_NUMKEY4.ordinal()] = (inputBits & 0x004) != 0; // turn left (numpad)
        gkd[ScanCode.SC_NUMKEY6.ordinal()] = (inputBits & 0x008) != 0; // turn right (numpad)
        gkd[ScanCode.SC_LEFT.ordinal()]    = (inputBits & 0x004) != 0; // turn left (arrow)
        gkd[ScanCode.SC_RIGHT.ordinal()]   = (inputBits & 0x008) != 0; // turn right (arrow)
        gkd[ScanCode.SC_LCTRL.ordinal()]   = (inputBits & 0x010) != 0; // fire
        gkd[ScanCode.SC_RCTRL.ordinal()]   = (inputBits & 0x010) != 0; // fire (alt)
        gkd[ScanCode.SC_SPACE.ordinal()]   = (inputBits & 0x020) != 0; // use
        gkd[ScanCode.SC_RSHIFT.ordinal()]  = (inputBits & 0x040) != 0; // run/speed
        gkd[ScanCode.SC_A.ordinal()]       = (inputBits & 0x080) != 0; // strafe left
        gkd[ScanCode.SC_D.ordinal()]       = (inputBits & 0x100) != 0; // strafe right
        // Weapon select: holding a number key in DOOM picks that slot.
        gkd[ScanCode.SC_1.ordinal()]       = (inputBits & 0x0200) != 0; // weapon 1 (fist/chainsaw)
        gkd[ScanCode.SC_2.ordinal()]       = (inputBits & 0x0400) != 0; // weapon 2 (pistol)
        gkd[ScanCode.SC_3.ordinal()]       = (inputBits & 0x0800) != 0; // weapon 3 (shotgun)
        gkd[ScanCode.SC_4.ordinal()]       = (inputBits & 0x1000) != 0; // weapon 4 (chaingun)
        gkd[ScanCode.SC_5.ordinal()]       = (inputBits & 0x2000) != 0; // weapon 5 (rocket)
        gkd[ScanCode.SC_6.ordinal()]       = (inputBits & 0x4000) != 0; // weapon 6 (plasma)
        gkd[ScanCode.SC_7.ordinal()]       = (inputBits & 0x8000) != 0; // weapon 7 (BFG)
    }

    /**
     * VTI headless integration: post a synthetic mouse-motion event with the
     * given horizontal delta so DOOM's G_BuildTiccmd applies an analog turn
     * (cmd.angleturn -= mousex * 8). Vertical delta is ignored for now.
     *
     * Bypasses the binary INPUT_TURN_LEFT/RIGHT bits to give smooth mouselook.
     * Call once per Lua frame with the accumulated dx; pass 0 to skip.
     */
    public static void setMouseTurnDelta(int dx) {
        if (dx == 0) return;
        getEngine().DOOM.PostEvent(new doom.event_t.mouseevent_t(
            doom.evtype_t.ev_mouse, 0, dx, 0));
    }

    /**
     * VTI headless integration: return the ARGB frame pixel raster.
     * Call after DOOM.TryRunTics() + DOOM.Display() to get the rendered frame.
     */
    public static int[] getFramePixels() {
        return ((v.renderers.BufferedRenderer32) getEngine().DOOM.graphicSystem).getRasterData();
    }
}
